#!/bin/bash

if [ $# -ne 1 ]; then
   echo "Uso: ./pruebas.sh PATRON" >&2
   exit 2
fi

patron="$1"

gcc -Wall -Wextra -Wpedantic -std=c11 -g -pthread src/hgrep.c -o hgrep

if [ $? -ne 0 ]; then
   exit 2
fi

grep -c -F "$patron" datos/*.txt >resultados/esperado.txt

TIMEFORMAT="%Rs"
error=0

for n in 1 2 4 8; do
   t=$( { time ./hgrep "$patron" $n datos/*.txt > resultados/salida.txt; } 2>&1 )

   if diff resultados/esperado.txt resultados/salida.txt > /dev/null; then
      echo "hilos=$n OK($t)"
   else
      echo "hilos=$n Falla($t)"
      error=1
   fi
done

for n in 1 2 4 8;do
   t=$( { time ./hgrep -f "$patron" $n datos/*.txt > resultados/salida.txt; } 2>&1 )
   if diff resultados/esperado.txt resultados/salida.txt > /dev/null; then
      echo "procesos=$n OK($t)"
   else
       echo "procesos=$n Falla ($t)"
      error=1
   fi
done 

exit $error
