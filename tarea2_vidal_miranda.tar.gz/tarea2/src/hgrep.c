#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct{
    long conteo;
    int error;
} Resultado;
typedef struct{
    int idx;
    Resultado res;
    }mensaje;

typedef struct{
    const char *palabra;
    char **archivos;
    int num_archivos;
    int siguiente;
    Resultado *resultados;
    pthread_mutex_t mutex_indice;


    int modo_encuentro;
    int esperados;
    int llegraon;
    long total;
    pthread_mutex_t mutex_enc;
    pthread_cond_t cond_enc;
} contexto;

typedef struct{
    contexto  *ctx;
    int id;
} argumento_hilo;


//contar las lineas de un archivo que contienen la palabra
static long contador_en_archivo(const char *ruta, const char *palabra, int *hubo_error){
    FILE *archivo = fopen(ruta,"r");
    if (archivo == NULL){
        fprintf(stderr,"hgrep: %s: %s\n",ruta,strerror(errno));
        *hubo_error = 1;
        return 0;
    }
    char *linea = NULL;
    size_t capacidad = 0;
    long contador = 0;

    while(getline(&linea,&capacidad,archivo)!= -1){
        if(strstr(linea, palabra)!= NULL){
            contador++;
       }
    }
    //debug
    if (ferror(archivo)){
        fprintf(stderr, "hgrep: %s: %s\n", ruta, strerror(errno));
        *hubo_error = 1;
        contador = 0;
    } else {
        *hubo_error = 0;
    }

     free(linea);
    fclose(archivo);
     return contador;
}
// funcion de cada hilo
static void *trabajador(void *arg){
    argumento_hilo *a = (argumento_hilo*)arg;
    contexto *ctx = a->ctx;
    long suma = 0;

    while(1){
        
        pthread_mutex_lock(&ctx->mutex_indice);
        int idx = ctx->siguiente;
        if (idx < ctx ->num_archivos){
            ctx -> siguiente++;
         }
        pthread_mutex_unlock(&ctx->mutex_indice);
            if (idx >= ctx->num_archivos){
            break;
        }
         
        int err=0;
        long c = contador_en_archivo(ctx->archivos[idx], ctx->palabra, &err);
        ctx->resultados[idx].conteo = c;
        ctx->resultados[idx].error = err;
        suma += c;
            
        
    }
   //punto de encuentro 
    if(ctx->modo_encuentro){
        pthread_mutex_lock(&ctx->mutex_enc);
        ctx->total += suma;
        ctx->llegraon++;
        if(ctx->llegraon == ctx->esperados){
            pthread_cond_broadcast(&ctx->cond_enc);
    }
    while(ctx->llegraon < ctx->esperados){
        pthread_cond_wait(&ctx->cond_enc, &ctx->mutex_enc);
    }
    long total = ctx->total;
    pthread_mutex_unlock(&ctx->mutex_enc);
    double porcentaje = (total > 0) ? (double)suma / total * 100.0 : 0.0;
    printf("hilo %d: %ld lineas (%.1f%% del total)\n" , a->id + 1, suma, porcentaje);
    }


    return NULL;
}

 static void mostrar_uso(void){
    fprintf(stderr,"Uso ./hgrep [-p |-f] patron N archivos\n");

    }
static int escribir_todo(int fd, const void *buf, size_t n){
    const char *p= (const char*)buf;
    size_t escrito= 0;

    while(escrito < n){
        ssize_t w = write(fd, p + escrito, n - escrito);
        if (w <0){
            if (errno == EINTR)continue;
            return -1;
  
        }
        escrito += (size_t)w;
    }
   return 0;    
}
static int leer_todo(int fd, void *buf, size_t n){
    char *p = (char*)buf;
    size_t leido = 0;
    while(leido < n){
        ssize_t r = read(fd, p + leido, n -leido);
        if (r == 0){
            return (leido == 0) ? 0 : -1;    
        }
        if(r < 0){
            if (errno == EINTR) continue;
            return -1;
        }
        leido += (size_t)r;
    }
    
    return 1;
}
    
static int ejecutar_procesos(const char *palabra, char **archivos, int num_archivos, int n_trabajadores,Resultado *resultados){
    int num_hijos = (n_trabajadores < num_archivos) ? n_trabajadores : num_archivos;
    int pipes[64][2];
    pid_t pids[64];
    int error_procesos = 0;
   
       for (int k = 0; k < num_hijos; k++) {
        if (pipe(pipes[k]) == -1) {
            perror("hgrep: pipe");
            for (int j = 0; j < k; j++) {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }
            return 1;
        }
    }   
    for (int k = 0; k < num_hijos; k++) {
        pids[k] = fork();
        if (pids[k] < 0) {
            perror("hgrep: fork");
            for (int j = k; j < num_hijos; j++) {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }
            for (int j = 0; j < k; j++) {
                close(pipes[j][0]);
                waitpid(pids[j], NULL, 0);
            }
            return 1;
        }
        if (pids[k] == 0) {  
            for (int j = 0; j < num_hijos; j++) {
                close(pipes[j][0]);
                if (j != k) {
                    close(pipes[j][1]);
                }
            }
            for (int i = k; i < num_archivos; i += num_hijos) {
                mensaje msg;
                memset(&msg, 0, sizeof(msg));
                msg.idx = i;
                msg.res.conteo = contador_en_archivo(archivos[i],palabra, &msg.res.error);
                if (escribir_todo(pipes[k][1], &msg, sizeof(mensaje))!= 0){
                    close(pipes[k][1]);
                    free(resultados);
                    _exit(1);
            
                }
            }
            close(pipes[k][1]);
            free(resultados);
            _exit(0);
        }
        close(pipes[k][1]);
    }
    for (int k = 0; k < num_hijos; k++) {
        mensaje msg;
        int st;
        while ((st = leer_todo(pipes[k][0], &msg, sizeof(mensaje))) == 1) {
            resultados[msg.idx] = msg.res;
        }
        if (st < 0) {
            error_procesos = 1;
        }
        close(pipes[k][0]);
    }
    for (int k = 0; k < num_hijos; k++) {
        int estado = 0;
        if (waitpid(pids[k], &estado, 0) < 0 || !WIFEXITED(estado) || WEXITSTATUS(estado) != 0) {
            error_procesos = 1;
        }
    }

    return error_procesos;

}   

    



int main(int argc, char *argv[]){
    int modo_procesos = 0;
    int modo_encuentro = 0;
    int pos = 1;
    if(pos < argc &&(strcmp(argv[pos],"-f") == 0 || strcmp(argv[pos],"-p") == 0)){
        if(strcmp(argv[pos],"-f") == 0){
            modo_procesos = 1;

        }else{
            modo_encuentro = 1;

        }
        pos++;    
    }
    if (argc - pos < 3){
        mostrar_uso();
        return 2;

    }
    const char *palabra = argv[pos];
    char *fin = NULL;
    long n_long = strtol(argv[pos + 1],&fin,10);
    if(fin == argv[pos +1] || *fin != '\0'|| n_long < 1 || n_long > 64){
        mostrar_uso();
        return 2;

    }
   int n_trabajadores =(int)n_long;
   char **archivos = &argv[pos + 2];
   int num_archivos = argc - (pos + 2);
   int num_hilos = (n_trabajadores < num_archivos) ? n_trabajadores: num_archivos;
   
   (void)modo_procesos;

   (void)modo_encuentro;
Resultado *resultados = calloc((size_t)num_archivos, sizeof(Resultado));
    if (resultados == NULL) {
        fprintf(stderr, "hgrep: error de memoria\n");
        return 2;
    }

    if (modo_procesos) {
        int err_proc = ejecutar_procesos(palabra, archivos, num_archivos, n_trabajadores, resultados);
        int hubo_error = err_proc;
        int hubo_coincidencia = 0;

        for (int i = 0; i < num_archivos; i++) {
            if (resultados[i].error) {
                hubo_error = 1;
                continue;
            }
            if (resultados[i].conteo > 0) {
                hubo_coincidencia = 1;
            }
            if (num_archivos == 1) {
                printf("%ld\n", resultados[i].conteo);
            } else {
                printf("%s:%ld\n", archivos[i], resultados[i].conteo);
            }
        }

        free(resultados);
        if (hubo_error) return 2;
        if (hubo_coincidencia) return 0;
        return 1;
    }



   pthread_t *hilos =  malloc((size_t)num_hilos * sizeof(pthread_t));
   argumento_hilo *args = malloc((size_t)num_hilos * sizeof(argumento_hilo));

   if (args == NULL || hilos == NULL){
    fprintf(stderr,"hgrep: error de memoria\n");
    free(resultados);
    free(hilos);
    free(args);
    return 2;
   }

    contexto ctx;
    ctx.palabra = palabra;
    ctx.archivos = archivos;
    ctx.num_archivos = num_archivos;
    ctx.siguiente = 0;
    ctx.resultados = resultados;
    pthread_mutex_init(&ctx.mutex_indice, NULL);
    ctx.modo_encuentro = modo_encuentro;
    ctx.esperados = num_hilos;
    ctx.llegraon = 0;
    ctx.total = 0;
    pthread_mutex_init(&ctx.mutex_enc, NULL);
    pthread_cond_init(&ctx.cond_enc, NULL);

      for(int i = 0; i < num_hilos; i++){
        args[i].ctx = &ctx;
        args[i].id = i;

          if(pthread_create(&hilos[i],NULL, trabajador, &args[i]) != 0){
               fprintf(stderr,"hgrep: error alS crear hilo\n");
               pthread_mutex_destroy(&ctx.mutex_indice);
               pthread_mutex_destroy(&ctx.mutex_enc);
                pthread_cond_destroy(&ctx.cond_enc);
               free(resultados);
               free(hilos);
               free(args);
               return 2;
            }

   }
   
   for (int i = 0; i < num_hilos; i++){
     pthread_join(hilos[i], NULL);

    }
    
   int hubo_error = 0;
   int hubo_coincidencia = 0;
   
   for(int i = 0; i < num_archivos; i++){
      if(resultados[i].error){
        hubo_error = 1;
        continue;
      }
      if (resultados[i].conteo > 0){
        hubo_coincidencia = 1;
      }
      if (num_archivos == 1){
        printf("%ld\n", resultados[i].conteo);
      } 
      else{
        printf("%s:%ld\n", archivos[i], resultados[i].conteo);
      }
   }
pthread_mutex_destroy(&ctx.mutex_enc);
pthread_cond_destroy(&ctx.cond_enc);
pthread_mutex_destroy(&ctx.mutex_indice);
free(resultados);
free(hilos);
free(args);

if(hubo_error){
    return 2;
}
if(hubo_coincidencia){
    return 0;
}
return 1;
}









/*
int main( int argc, char *argv[]){
    if(argc !=2){
        fprintf(stderr,"error: deber escribir un argumento valido maximo 1 \n");
        return 1;  //retorna el error del prgrama si hay mas de un argumentos 

    }

char *palabra = argv[1];
char linea[Maxima_lineas];
int contador = 0;  // se crea una variable contador para contar las lineas que contiene la palabra 
    while (fgets(linea, Maxima_lineas, stdin) != NULL){
        if (strstr(linea, palabra) != NULL){ // strstr busca la palabra dentro de la linea 
            contador++;

        }
    }
printf("%d\n",contador); // imprime el numero de lineas que tiene la palabra 
    return 0; // retorna la operacion del programa de manera correcta 



}*/